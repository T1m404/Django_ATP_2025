from django import forms
from .models import Comment

class UserForm(forms.Form):
    name = forms.CharField()
    email = forms.EmailField(max_length=30)
    text_body = forms.CharField(max_length=200)

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['name', 'comment_body']
        # post = forms.IntegerField()
        # name = forms.CharField(max_length=30)
        # comment_body = forms.CharField(max_length=250)
