from django import forms

class UserForm(forms.Form):
    name = forms.CharField()
    email = forms.CharField(max_length=30)
    text_body = forms.CharField(max_length=200)

class Comment(forms.Form):
    name = forms.CharField()
    comment_body = forms.CharField()
