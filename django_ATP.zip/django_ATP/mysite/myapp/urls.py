from django.urls import path
from . import views
app_name = 'myapp'
urlpatterns = [
    path('', views.main),
    path('home/', views.home, name='home'),
    path('home/by_title', views.home_by_title, name='by_title'),
    path('home/by_slug', views.home_by_slug, name='by_slug'),
    path('home/by_author', views.home_by_author, name='by_author'),
    path('blog/', views.blog),
    path('blog/<int:post_id>', views.post_detail, name='post_detail'),
    path('forms/', views.forms, name='forms'),
    path('feedback/', views.feedback_view, name='feedback_form'),
    path('success/', views.forms_success, name='feedback_success'),
    path('blog/<int:post_id>', views.post_comment, name='post_comment'),
]


