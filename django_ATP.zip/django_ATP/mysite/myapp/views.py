from django.shortcuts import render, get_object_or_404
from .models import Post
from .forms import UserForm



# Create your views here.
def home(request):
    posts = Post.objects.all()
    context = {'posts': posts}
    return render(request, 'index.html', context)

def home_by_title(request):
    posts = Post.objects.all().order_by('-title')
    context = {'posts': posts}
    return render(request, 'index.html', context)

def home_by_slug(request):
    posts = Post.objects.all().order_by('-slug')
    context = {'posts':posts}
    return render(request, 'index.html', context)

def home_by_author(request):
    posts = Post.objects.all().filter(author='2')
    context = {'posts': posts}
    return render(request, 'index.html', context)


def post_detail(request, post_id):
    post = get_object_or_404(Post, id=post_id, status=Post.Status.PUBLISHED)
    context = {"post": post}
    return render(request, 'post_detail.html', context)


def blog(request):
    return render(request, 'blog.html')
#
# def forms(request):
#     return render(request, 'forms.html')
# def form_returns(request):
#     if form.is_valid():
#         return HttpResponseRedirect("/thanks/")
#
#         # if a GET (or any other method) we'll create a blank form
#     else:
#         form = NameForm()
#
#     return render(request, "name.html", {"form": form})

def main(request):
    return render(request, 'main.html')

def forms(request):
    userform = UserForm()
    return render(request, 'forms.html', {'form': userform})

def comment(request):
    return render(request, '')
