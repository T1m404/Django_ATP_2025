
from django.urls import path
from . import views
app_name = 'myapp'
urlpatterns = [
    path('home/', views.home),
    path('home/by_title', views.home_by_title, name='by_title'),
    path('home/by_slug', views.home_by_slug, name='by_slug'),
    path('home/by_author', views.home_by_author, name='by_author'),
    path('blog/', views.blog),
    path('blog/<int:post_id>', views.post_detail, name='post_detail'),
    path('forms/', views.forms, name='forms')
]